import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import customtkinter as ctk
from PIL import Image
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
import os
from PIL import Image


SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
ICON_DIR   = os.path.join(SCRIPT_DIR, "Icons")


# Importe aus der Logik
from Logik.Wasser_und_Temperatur import Wasser_und_Temperatur
from Logik.Wirtschaftlichkeit_Logik.Wirtschaftlichkeit import (
    erhalte_ausgabewerte,
    lade_komponenten,
    lade_verschleissdaten,
    berechne_investitionskosten,
    berechne_verschleisskosten,
    berechne_verkaufsgewinn,
    berechne_rentabilität
)



# Einstellungen
ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("green")


class App(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("Wirtschaftlichkeitsberechnung")
        self.geometry("1024x720")
        self.configure(fg_color="black")

        # Layoutstruktur
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(2, weight=1)

        # Header
        header = ctk.CTkFrame(self, fg_color="black", height=60)
        header.grid(row=0, column=0, columnspan=2, sticky="ew")
        header.grid_columnconfigure(1, weight=1)

        # Pflanze und Titel in einer Linie
        plant_label = ctk.CTkLabel(header, text="🌱", font=("Arial", 68), text_color="#4CAF50")
        plant_label.grid(row=0, column=0, padx=(20, 10), pady=20, sticky="w")

        self.header_label = ctk.CTkLabel(header, text="Wirtschaftlichkeitsberechnung", font=("Arial", 36), text_color="white")
        self.header_label.grid(row=0, column=1, pady=10, sticky="nsew")

        #  Grüner stroke
        line = ctk.CTkFrame(self, height=2, fg_color="green")
        line.grid(row=1, column=0, columnspan=2, sticky="ew")

        # Sidebar
        self.sidebar = ctk.CTkFrame(self, width=130, fg_color="#0B3A3E", corner_radius=0)
        self.sidebar.grid(row=2, column=0, sticky="ns")
        self.sidebar.grid_propagate(False)

        # Icons und Buttons
        self.nav_buttons = {}
        self.icons_normal = {
    "Home": ctk.CTkImage(
        Image.open(os.path.join(ICON_DIR, "Home_weiß.png")), size=(40,40)
    ),
    "Solar": ctk.CTkImage(
        Image.open(os.path.join(ICON_DIR, "sonne_weiß.png")), size=(40,40)
    ),
    "Wind": ctk.CTkImage(
        Image.open(os.path.join(ICON_DIR, "Wind_weiß.png")), size=(40,40)
    ),
    "Invest": ctk.CTkImage(
        Image.open(os.path.join(ICON_DIR, "Invest_weiß.png")), size=(40,40)
    ),
}

      
        self.icons_active = {
            "Home": ctk.CTkImage(
                Image.open(os.path.join(ICON_DIR, "Home_grün_t.png")), size=(40, 40)
            ),
            "Solar": ctk.CTkImage(
                Image.open(os.path.join(ICON_DIR, "sonne_grün_t.png")), size=(40, 40)
            ),
            "Wind": ctk.CTkImage(
                Image.open(os.path.join(ICON_DIR, "Wind_grün_t.png")), size=(40, 40)
            ),
            "Invest": ctk.CTkImage(
                Image.open(os.path.join(ICON_DIR, "Invest_grün_t.png")), size=(40, 40)
            ),
        }
        

        nav = [("Home", "Home"), ("Solar", "Solar"), ("Wind", "Wind"), ("Invest", "Invest")]
        for page_key, label in nav:
            btn = ctk.CTkButton(
                self.sidebar,
                text=label,
                image=self.icons_normal[page_key],
                compound="top",
                corner_radius=15,
                fg_color="transparent",
                hover_color=None,
                text_color="white",
                font=("Arial", 14),
                command=lambda p=page_key: self.activate_button(p),
            )
            btn.pack(pady=30, padx=20, fill="x")
            self.nav_buttons[page_key] = btn

        # main_area
        self.main_area = ctk.CTkFrame(self, fg_color="black")
        self.main_area.grid(row=2, column=1, sticky="nsew")

        # Seiten
        self.pages = {
            "Home": HomePage(self.main_area),
            "Solar": SolarPage(self.main_area),
            "Wind": WindPage(self.main_area),
            "Invest": InvestPage(self.main_area),
        }

        self.show_page("Home")


    def activate_button(self, name):
        for key, btn in self.nav_buttons.items():
            btn.configure(image=self.icons_normal[key])
        self.nav_buttons[name].configure(image=self.icons_active[name])
        self.show_page(name)

    def show_page(self, name):
        for page in self.pages.values():
            page.grid_forget()
        if name in self.pages:
            self.pages[name].grid(row=0, column=0, sticky="nsew")

            titles={
                "Home": "Wirtschaftlichkeitsberechnung",
                "Solar": "Solarstrom und Kosten",
                "Wind": "Windstrom und Kosten", 
                "Invest": "Investitionsübersicht"
            }

            self.set_title(titles.get(name,""))

    def set_title(self, neuer_titel):
        self.header_label.configure(text=neuer_titel)


# Home-Seite

class HomePage(ctk.CTkFrame):
    def __init__(self, parent):
        super().__init__(parent, fg_color="black")
        self.grid_columnconfigure((0, 1), weight=1)
        self.grid_rowconfigure(0, weight=0)
        self.grid_rowconfigure(1, weight=0)
        self.grid_rowconfigure(2, weight=0)
        self.grid_rowconfigure(3, weight=0)
        self.grid_rowconfigure(4, weight=1) 

        # Trennlinie
        green_line = ctk.CTkFrame(self, height=1, fg_color="green")
        green_line.grid(row=0, column=0, columnspan=20, sticky="ew", padx=10, pady=(0, 20))

        left_container = ctk.CTkFrame(self, fg_color="black", width=380, height=500)
        left_container.grid(row=1, column=0, sticky="n", padx=0, pady=0)
        left_container.grid_propagate(False)
        left_container.grid_rowconfigure(0, weight=0)  # grüne Box
        left_container.grid_rowconfigure(1, weight=0)  # Label
        left_container.grid_rowconfigure(2, weight=0)  # Eingabeframe
        left_container.grid_rowconfigure(3, weight=1)  # Rest
       
        # Grüne Box links
        green_box = ctk.CTkFrame(left_container, width=300, height=350, border_color="green", border_width=2, fg_color="black")
        green_box.grid(row=1, column=0, padx=40, pady=(30, 10), sticky="n")
        green_box.grid_propagate(False)  # verhindert automatische Größenanpassung
        bild_pfad = os.path.join(SCRIPT_DIR, "Bild.png")
        img = ctk.CTkImage(Image.open(bild_pfad), size=(280,320))
        img_label = ctk.CTkLabel(green_box, image=img, text="")
        img_label.place(relx=0.5, rely=0.5, anchor="center")  # zentriert das Bild

        # Eingabeüberschrift
        eingabe_label = ctk.CTkLabel(left_container, text="Betriebsdauer (Jahre):", font=("Arial", 16))
        eingabe_label.grid(row=2, column=0, padx=40, pady=(0, 0), sticky="s")

        # Eingabeframe mit Entry und Button
        eingabe_frame = ctk.CTkFrame(left_container, width=300, height=80, border_color="green", border_width=2, fg_color="black")
        eingabe_frame.grid(row=3, column=0, padx=40, pady=(0, 30), sticky="n")
        eingabe_frame.grid_propagate(False)

        self.jahr_entry = ctk.CTkEntry(eingabe_frame, width=100)
        self.jahr_entry.insert(0, "10")
        self.jahr_entry.grid(row=0, column=1, padx=10, pady=10)

        self.berechnen_button = ctk.CTkButton(eingabe_frame, text="Berechnen", command=self.berechne_werte)
        self.berechnen_button.grid(row=0, column=2, padx=10, pady=10)

        right_container= ctk.CTkFrame(self, fg_color="black",height=500, width=340)
        right_container.grid(row=1, column=1, padx=20, pady=20, sticky="nsew")
        right_container.grid_propagate(False)

        for r in (0,1,2):
            right_container.grid_rowconfigure(r, weight=0)
            right_container.grid_columnconfigure(0, weight=1)
                                    

        # Initiale Werte abrufen
        investition, verschleiss, rentabilität = erhalte_ausgabewerte(10)
        werte = [f"{investition:.2f} €", f"{verschleiss:.2f} €", f"{rentabilität:.2f} €"]
        labels = ["Gewinn", "Betriebskosten", "Rentabilität"]

        self.wert_labels = []  # zum späteren Aktualisieren

        self.grid_columnconfigure(1, weight=2)
        self.grid_rowconfigure(3, minsize=80)
        
        
        for idx, (hdr, val) in enumerate(zip(labels,werte)):
            lbl = ctk.CTkLabel(right_container, text=hdr, font=("Arial", 20), text_color="white")
            lbl.grid(row=idx*2, column=0, sticky="n", pady=(0,5))

            # Die eigentliche Wert-Box
            box = ctk.CTkFrame(right_container, fg_color="#11393D", corner_radius=10,width=300, height=110)
            box.grid(row=idx*2+1, column=0, pady=(0,20), padx=20,sticky="n")
            box.grid_propagate(False) #keine größen anpassung

            # Wert zentriert
            wert_label=ctk.CTkLabel(box, text=val, font=("Arial", 30, "bold"), text_color="white")
            wert_label.place(relx=0.5, rely=0.5, anchor="center")
            self.wert_labels.append(wert_label)


    def berechne_werte(self):
        try:
            jahre = int(self.jahr_entry.get())
            if jahre <= 0:
                raise ValueError
        except ValueError:
            # Fehlertext anzeigen
            self.wert_labels[0].configure(text="Falsche Eingabe")
            self.wert_labels[1].configure(text="Ungültig")
            self.wert_labels[2].configure(text="Eingabe")
            return

        # Neue Werte berechnen
        gewinn, verschleiss, rentabilität = erhalte_ausgabewerte(jahre)
        neue_werte = [gewinn, verschleiss, rentabilität]

        # Bestehende Labels aktualisieren (Frames bleiben erhalten)
        for label, wert in zip(self.wert_labels, neue_werte):
            label.configure(text=f"{wert:.2f} €")


# Solar-Seite

from Logik.Stromkosten_und_Solar.Solarstrom_und_Verbrauch import pv_flow
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from Logik.Stromkosten_und_Solar.Solar_und_Wind import solar_wind_figure

class SolarPage(ctk.CTkFrame):
    def __init__(self, parent):
        super().__init__(parent, fg_color="black")
        self.grid_columnconfigure(0, weight=1)
    
        info = [("Solarstrom und Verbrauch", 1), ("Gesamtstrom erzeugung und Verbrauch", 2)]


        for idx, (label, row) in enumerate(info):
            ctk.CTkLabel(self, text=label, font=("Arial", 20)).grid(row=row * 2 - 1, column=0, pady=(10, 0), padx=(100, 0), sticky="w")
            box = ctk.CTkFrame(self, width=600, height=210, fg_color="#11393D", corner_radius=10)
            box.grid(row=row * 2, column=0, pady=(20, 20), padx=(100, 0), sticky="w")

            if idx == 0:  # oberer Plot
                fig, pv, verbrauch = pv_flow()
                canvas = FigureCanvasTkAgg(fig, master=box)
                canvas.get_tk_widget().pack(fill="both", expand=True)
                canvas.draw()
            elif idx == 1:  # unterer Plot
                fig= solar_wind_figure()
                canvas = FigureCanvasTkAgg(fig, master=box)
                canvas.get_tk_widget().pack(fill="both", expand=True)
                canvas.draw()




# Wind-Seite

from Logik.Wasser_und_Temperatur.Wasser_und_Temperatur import auswertung
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from Logik.Windstrom.Windstrom import wind_flow
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

class WindPage(ctk.CTkFrame):
    def __init__(self, parent):
        super().__init__(parent, fg_color="black")
        self.grid_columnconfigure(0, weight=1)


        info = [("Windstrom", 1), ("Wasserkosten und Verbrauch", 2)]

        for idx, (label, row) in enumerate(info):
            ctk.CTkLabel(self, text=label, font=("Arial", 20)).grid(row=row * 2 - 1, column=0, pady=(10, 0), padx=(100, 0), sticky="w")
            box = ctk.CTkFrame(self, width=600, height=210, fg_color="#11393D", corner_radius=10)
            box.grid(row=row * 2, column=0, pady=(20, 20), padx=(100, 0), sticky="w")

            if idx == 0:  # oberer Plot
                fig, wind, verbrauch = wind_flow()
                canvas = FigureCanvasTkAgg(fig, master=box)
                canvas.get_tk_widget().pack(fill="both", expand=True)
                canvas.draw()
            elif idx == 1:  # unterer Plot
                fig= auswertung ()
                canvas = FigureCanvasTkAgg(fig, master=box)
                canvas.get_tk_widget().pack(fill="both", expand=True)
                canvas.draw()


        

# Invest-Seite
from Logik.Wirtschaftlichkeit_Logik.Wirtschaftlichkeit import erhalte_investition

class InvestPage(ctk.CTkFrame):
    def __init__(self, parent):
        super().__init__(parent, fg_color="black")
        # === 1. Grid-Konfiguration ===
        # Spalte 0 darf wachsen, Spalte 1 ist fix
        self.grid_columnconfigure(0, weight=1)
        self.grid_columnconfigure(1, weight=0)
        # Zeile 0 für Überschrift, Zeilen 1–4 für den Inhalt
        for r in range(1, 5):
            self.grid_rowconfigure(r, weight=1)

        #  2. Überschrift 
        ctk.CTkLabel(self,
                     text="Komponenten",
                     font=("Arial", 20),
                     text_color="white",
                     anchor="center"
                    ).grid(row=0, column=0, padx=40, pady=(20, 5), sticky="nsew")

        # 3. Linke scrollbare Komponenten-Box 
        ctk.CTkLabel(self, text="Total", font=("Arial",20), text_color="white").grid(row=3, column=1, padx=20, pady=(0, 5), sticky="nsew")
        ctk.CTkFrame(self, width=300, height=110, fg_color="#11393D", corner_radius=10).grid(row=4, column=1, padx=20, pady=(0, 20), sticky="n")
        
        self.komponenten_box = ctk.CTkScrollableFrame(self,
                                                      width=300,
                                                      height=400,
                                                      fg_color="#11393D",
                                                      scrollbar_fg_color="#11393D",
                                                      scrollbar_button_color="#4CAF50"
                                                     )
        # über die Zeilen 1–4 ziehen
        self.komponenten_box.grid(row=1, column=0, rowspan=4,
                                  padx=(40,20), pady=20, sticky="nsew")

        # lade aus Datei
        self.load_components("Logik/Wirtschaftlichkeit_Logik/Komponenten.txt")

        #  4. Rechte Info-Box 1: „Noch kein Plan“ 
        ctk.CTkLabel(self,
                     text="Noch kein Plan",
                     font=("Arial", 20),
                     text_color="white"
                    ).grid(row=1, column=1, sticky="nsew", padx=20, pady=(20, 5))
        ctk.CTkFrame(self,
                     width=300,
                     height=110,
                     fg_color="#11393D",
                     corner_radius=10
                    ).grid(row=2, column=1, padx=20, pady=(0, 20), sticky="n")

        # Total Box 
        self.total_frame = ctk.CTkFrame(self,
                                        width=300, height=110,
                                        fg_color="#11393D",
                                        corner_radius=10)
        self.total_frame.grid(row=4, column=1, padx=20, pady=(0,20))
        self.total_frame.grid_propagate(False)

        self.total_value = ctk.CTkLabel(self.total_frame,
                                        text="0,00 €",
                                        font=("Arial", 30, "bold"),
                                        text_color="white")
        self.total_value.pack(expand=True, fill="both")

        # am Ende: Investitionskosten holen und anzeigen
        self.update_total()

    def update_total(self):
        invest = erhalte_investition()
        self.total_value.configure(text=f"{invest:.2f} €")

        #Komponenten Box
    def load_components(self, dateipfad):
        try:
            with open(dateipfad, "r", encoding="utf-8") as f:
                lines = f.readlines()
        except FileNotFoundError:
            ctk.CTkLabel(self.komponenten_box,
                         text="Datei nicht gefunden!",
                         text_color="red").grid(padx=10, pady=10)
            return

        for idx, roh in enumerate(lines):
            roh = roh.strip()
            if not roh or ":" not in roh:
                continue
            name, preis = [teil.strip() for teil in roh.split(":", 1)]
            text = f"{name}: {preis} €"
            ctk.CTkLabel(self.komponenten_box,
                         text=text,
                         font=("Arial", 16),
                         text_color="white"
                        ).grid(row=idx, column=0, sticky="w", padx=10, pady=5)
            
    



if __name__ == "__main__":
    app = App()
    app.mainloop()

   