def wind_flow(
    path_wind="Logik/Windstrom/Winddaten.txt",
    path_wka="Logik/Windstrom/powerData_Enercon_E175.txt",
    path_temp='Logik/Stromkosten_und_Solar/Temperaturdaten.txt',
    pflanzen=10,
    grundverbrauch_watt=145,
    n_wka=5,
    startdate='2023-01-01 00:00',
    enddate='2023-12-31 23:50'
):
    import numpy as np
    import pandas as pd
    from matplotlib.figure import Figure
    from matplotlib.ticker import MaxNLocator
    import matplotlib.dates as mdates
    from scipy import interpolate
    import warnings
    warnings.simplefilter(action='ignore', category=FutureWarning)

    # Gießfunktion
    def wasserverbrauch(temp, pflanzen=10):
        if temp < 5:
            basis = 0.05
        elif temp > 35:
            basis = 0.7
        else:
            basis = 0.05 + (temp - 5) * (0.65 / 30)
        return basis * pflanzen

    # Zeitraum
    startdate = pd.to_datetime(startdate)
    enddate = pd.to_datetime(enddate)

    # Winddaten einlesen und interpolieren
    data_wind = pd.read_csv(path_wind, sep=';', na_values=-999)
    data_wind['MESS_DATUM'] = pd.to_datetime(data_wind['MESS_DATUM'], format='%Y%m%d%H%M')
    data_wind.interpolate(inplace=True)
    maske_wind = (data_wind['MESS_DATUM'] >= startdate) & (data_wind['MESS_DATUM'] <= enddate)
    data_wind = data_wind.loc[maske_wind].copy()
    data_wind['Datum'] = data_wind['MESS_DATUM'].dt.date

    # Windkennlinie einlesen und Interpolator bauen
    data_wka = pd.read_csv(path_wka, sep=';', decimal=',')
    f_wind2power = interpolate.interp1d(
        data_wka["Windgeschwindigkeit (m/s)"],
        data_wka["Leistung (kW)"],
        kind='linear',
        bounds_error=False,
        fill_value=(0, data_wka["Leistung (kW)"].max())
    )

    def windleistung(vel_array):
        return f_wind2power(vel_array)

    # Windpark-Leistung und Tagesenergie berechnen
    dt_h = 600 / 3600  # 600 s = 10 min = 0.1667 h
    data_wind['Leistung_kW'] = n_wka * windleistung(data_wind['FF_10'].values)
    tagesertrag_wind = data_wind.groupby('Datum')['Leistung_kW'].sum() * dt_h

    # Temperaturdaten einlesen und Tagesmittel berechnen
    data_temp = pd.read_csv(path_temp, sep=';', na_values=-999)
    data_temp['MESS_DATUM'] = pd.to_datetime(data_temp['MESS_DATUM'], format='%Y%m%d%H%M')
    data_temp['TT_10'].interpolate(inplace=True)
    data_temp['Datum'] = data_temp['MESS_DATUM'].dt.date
    tagesmittel_temp = data_temp.groupby('Datum')['TT_10'].mean()
    tagesmittel_temp = tagesmittel_temp.reindex(tagesertrag_wind.index)

    # Wasserverbrauch und Pumpenenergie
    wasser_liter = tagesmittel_temp.apply(lambda t: wasserverbrauch(t, pflanzen=pflanzen))
    pumpen_kwh = wasser_liter * 0.0006  # 0.6 Wh/liter → 0.0006 kWh/l

    # Grundlast pro Tag
    grund_kwh = grundverbrauch_watt / 1000  # in kWh

    # Gesamtverbrauch pro Tag
    verbrauch_windjahr = grund_kwh + pumpen_kwh

    # ----------- Plot im Wasserplot-Stil -----------
    fig = Figure(figsize=(6, 2.1), dpi=100, constrained_layout=True, facecolor="#11393D")
    ax1 = fig.add_subplot(111)
    ax1.set_facecolor("#11393D")
    ax1.plot(
        tagesertrag_wind.index,
        tagesertrag_wind,
        marker="o", markersize=3, color='skyblue', linewidth=0.8, label='Windenergie (kWh)'
    )
    ax1.set_ylabel('Windenergie (kWh)', fontsize=8, color='skyblue')
    ax1.tick_params(axis='y', labelsize=6, colors="skyblue")
    ax1.tick_params(axis='x', labelsize=6, rotation=45, colors="white")
    ax1.set_xlabel("Datum", fontsize=8, labelpad=2, color="white")
    ax1.xaxis.set_major_locator(MaxNLocator(nbins=8, integer=True))
    ax1.xaxis.set_major_formatter(mdates.DateFormatter('%b'))
    ax1.grid(True, linestyle="--", color="gray", alpha=0.3)

    # Rechte y-Achse: Verbrauch
    ax2 = ax1.twinx()
    ax2.plot(
        verbrauch_windjahr.index,
        verbrauch_windjahr,
        marker="x", markersize=3, color='gold', linewidth=0.8, linestyle='--', label='Verbrauch (kWh)'
    )
    ax2.set_ylabel("Verbrauch (kWh)", fontsize=8, color='gold')
    ax2.tick_params(axis='y', labelsize=6, colors="gold")

    # Legenden zusammenführen
    lines1, labels1 = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    legend = ax1.legend(lines1 + lines2, labels1 + labels2, fontsize=6, facecolor="#11393D", edgecolor="none", loc='upper left')
    for text in legend.get_texts():
        text.set_color("white")

    # Overlay mit Gesamt-Stats
    fig.text(
        0.95, 0.02,
        f"Summe Wind: {tagesertrag_wind.sum():.1f} kWh\n"
        f"Summe Verbrauch: {verbrauch_windjahr.sum():.1f} kWh",
        ha="right",
        va="bottom",
        fontsize=6,
        color="white",
        bbox=dict(facecolor="#11393D", pad=2, edgecolor="none", alpha=0.7)
    )

    return fig, tagesertrag_wind, verbrauch_windjahr