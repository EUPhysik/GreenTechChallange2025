import matplotlib.pyplot as plt
from collections import defaultdict
from datetime import datetime
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
from collections import defaultdict
from datetime import datetime
import os
import matplotlib.dates as mdates
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATEN_PFAD = os.path.join(SCRIPT_DIR, "Wetter_Daten_Dortmund.txt")


def wasserverbrauch(temp, pflanzen=10):
    if temp < 5:
        basis = 0.05
    elif temp > 35:
        basis = 0.7
    else:
        basis = 0.05 + (temp - 5) * (0.65 / 30)
    return basis * pflanzen

def auswertung(pflanzen=10, wasserpreis=0.001263):
    # — Daten einlesen und Mitteltemperaturen berechnen —
    tageweise_temp = defaultdict(list)
    with open(DATEN_PFAD, 'r', encoding='utf-8') as f:
        next(f)
        for zeile in f:
            teile = zeile.strip().split(";")
            if len(teile) < 32 or teile[31] in ("", "-999"):
                continue
            try:
                datum = datetime.strptime(teile[2], "%Y-%m-%d").date()
                temp  = float(teile[31].replace(",", "."))
                tageweise_temp[datum].append(temp)
            except:
                continue

    tage      = sorted(tageweise_temp)
    verbrauch = [ wasserverbrauch(sum(temps)/len(temps), pflanzen)
                  for temps in (tageweise_temp[d] for d in tage) ]
    kosten    = [ v * wasserpreis for v in verbrauch ]

    gesamtverbrauch = sum(verbrauch)
    gesamtkosten    = sum(kosten)

    fig = Figure(figsize=(6, 2.1), dpi=100, constrained_layout=True, facecolor="#11393D")
    ax1 = fig.add_subplot(111)
    ax1.set_facecolor("#11393D")
    ax2 = ax1.twinx()

    # Verbrauch auf ax1 (linke Achse)
    ax1.plot(tage, verbrauch, marker='o', markersize=4,
             linewidth=2, color='lightcyan', label="Verbrauch (L)")

    # Kosten auf ax2 (rechte Achse)
    ax2.plot(tage, kosten, marker='x', markersize=3,
             linewidth=1, color='gold', label="Kosten (€)")
    min_kosten = min(kosten)
    max_kosten = max(kosten)
    abstand = (max_kosten - min_kosten) * 0.2 if max_kosten > min_kosten else 1
    ax2.set_ylim(min_kosten - abstand, max_kosten + abstand)

    # Achsenbeschriftungen
    ax1.set_ylabel("Liter", fontsize=8, labelpad=2, color="white")
    ax2.set_ylabel("Kosten (€)", fontsize=8, labelpad=2, color="gold")

    # Achsen-Design
    ax1.tick_params(axis='y', labelsize=6, colors="white")
    ax2.tick_params(axis='y', labelsize=6, colors="gold")
    ax1.tick_params(axis='x', labelsize=6, rotation=45, colors="white")

    # Legenden zusammenführen
    lines, labels = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(lines + lines2, labels + labels2, fontsize=6, facecolor="#11393D", edgecolor="none")

    # Optional: Titel, Text, etc.
    ax1.set_title("Wasserverbrauch & Kosten je Tag", fontsize=10, pad=4, color="white")

    return fig