# Importe
import os
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
KOMPONENTEN_DATEI = os.path.join(SCRIPT_DIR, "Komponenten.txt")
VERSCHLEISS_DATEI = os.path.join(SCRIPT_DIR, "Verschleiss.txt")

# Daten
BETRIEBSDAUER_JAHRE = 10

VERKAUFSPREIS = 2.50  # € pro Stück
STÜCK_PRO_QUARTAL = 10


# Funktionen

def lade_komponenten(pfad: str) -> dict:
    komponenten = {}
    try:
        with open(pfad, "r") as file:
            for line in file:
                if ":" in line:
                    try:
                        name, wert = line.strip().split(":")
                        komponenten[name.strip()] = float(wert.strip())
                    except ValueError:
                        print(f"⚠️ Ungültige Zeile übersprungen: {line.strip()}")
    except Exception as e:
        print("Fehler beim Laden der Komponenten:", e)
    return komponenten


def berechne_investitionskosten(komponenten: dict) -> float:
    return sum(komponenten.values())

def lade_verschleissdaten(pfad: str) -> list:
    komponenten = []
    try:
        with open(pfad, "r") as f:
            for line in f:
                if ":" in line:
                    teile = line.strip().split(":")
                    if len(teile) == 3:
                        name = teile[0].strip()
                        preis = float(teile[1].strip())
                        lebensdauer = float(teile[2].strip())
                        komponenten.append({
                            "name": name,
                            "preis": preis,
                            "lebensdauer": lebensdauer
                        })
    except Exception as e:
        print("Fehler beim Laden der Verschleißdaten:", e)
    return komponenten

def berechne_verschleisskosten(komponenten: list, betriebsjahre: int) -> float:
    kosten = 0.0
    for k in komponenten:
        anteil = betriebsjahre / k["lebensdauer"]
        anteil = min(anteil, 1.0)
        kosten += k["preis"] * anteil
    return kosten

def berechne_verkaufsgewinn(jahre: int, stück_pro_quartal: int, preis: float) -> float:
    quartale = jahre * 4
    anzahl_stücke = quartale * stück_pro_quartal
    return anzahl_stücke * preis

def berechne_rentabilität(investition: float, verschleiss: float, gewinn: float) -> float:
    gesamtkosten = investition + verschleiss
    return gewinn - gesamtkosten


# Dartellung Terminal

def main():
    


    print("🔍 Investitions- & Rentabilitätsrechnung (Produktverkauf)")
    print("=" * 60)

    komponenten = lade_komponenten(KOMPONENTEN_DATEI)
    verschleissdaten = lade_verschleissdaten(VERSCHLEISS_DATEI)

    investition = berechne_investitionskosten(komponenten)
    verschleiss = berechne_verschleisskosten(verschleissdaten, BETRIEBSDAUER_JAHRE)
    gewinn = berechne_verkaufsgewinn(BETRIEBSDAUER_JAHRE, STÜCK_PRO_QUARTAL, VERKAUFSPREIS)
    rentabilität = berechne_rentabilität(investition, verschleiss, gewinn)

    print("\n💰 Investitionskosten:")
    for name, wert in komponenten.items():
        print(f"  {name:20}: {wert:.2f} €")
    print(f"  → Gesamt: {investition:.2f} €")

    print("\n⚙️ Verschleißkosten (für", BETRIEBSDAUER_JAHRE, "Jahre):")
    for k in verschleissdaten:
        anteil = min(BETRIEBSDAUER_JAHRE / k["lebensdauer"], 1.0)
        teilkosten = k["preis"] * anteil
        print(f"  {k['name']:20}: {teilkosten:.2f} € ({anteil*100:.1f} %)")
    print(f"  → Gesamt: {verschleiss:.2f} €")

    print("\n📦 Produktionsgewinn:")
    print(f"  {STÜCK_PRO_QUARTAL} Stück × 4 Quartale × {BETRIEBSDAUER_JAHRE} Jahre × {VERKAUFSPREIS:.2f} € = {gewinn:.2f} €")

    print("\n📈 Rentabilitätsrechnung:")
    print(f"  Gesamtkosten (Invest + Verschleiß): {investition + verschleiss:.2f} €")

    if rentabilität >= 0:
        print(f"✅ Rentabel: +{rentabilität:.2f} € Gewinn über {BETRIEBSDAUER_JAHRE} Jahre")
    else:
        print(f"❌ Nicht rentabel: {rentabilität:.2f} € Verlust über {BETRIEBSDAUER_JAHRE} Jahre")

def erhalte_ausgabewerte(jahre: int):
    komponenten = lade_komponenten(KOMPONENTEN_DATEI)
    verschleissdaten = lade_verschleissdaten(VERSCHLEISS_DATEI)

    investition = berechne_investitionskosten(komponenten)
    verschleiss = berechne_verschleisskosten(verschleissdaten, jahre)
    gewinn = berechne_verkaufsgewinn(jahre, STÜCK_PRO_QUARTAL, VERKAUFSPREIS)
    rentabilität = berechne_rentabilität(investition, verschleiss, gewinn)

    return gewinn, verschleiss, rentabilität

def erhalte_investition() -> float:
    komponenten = lade_komponenten(KOMPONENTEN_DATEI)
    return berechne_investitionskosten(komponenten)


if __name__ == "__main__":
    main()
