def pv_flow(
    path_solar='Logik/Stromkosten_und_Solar/Solardaten.txt',
    path_temp='Logik/Stromkosten_und_Solar/Temperaturdaten.txt',
    path_faktor='Logik/Stromkosten_und_Solar/df_globstrahl_faktor',
    pflanzen=10,
    grundverbrauch_watt=145,
    startdate='2023-01-01 00:00',
    enddate='2023-12-31 23:50'
):
    import numpy as np
    import pandas as pd
    from matplotlib.figure import Figure
    from matplotlib.ticker import MaxNLocator
    import warnings
    warnings.simplefilter(action='ignore', category=FutureWarning)

    def wasserverbrauch(temp, pflanzen=10):
        if temp < 5:
            basis = 0.05
        elif temp > 35:
            basis = 0.7
        else:
            basis = 0.05 + (temp - 5) * (0.65 / 30)
        return basis * pflanzen

    # Daten einlesen
    data_solar = pd.read_csv(path_solar, sep=';', na_values=-999)
    data_solar['MESS_DATUM'] = pd.to_datetime(data_solar['MESS_DATUM'], format='%Y%m%d%H%M')
    data_solar['GS_10'].interpolate(inplace=True)

    data_temp = pd.read_csv(path_temp, sep=';', na_values=-999)
    data_temp['MESS_DATUM'] = pd.to_datetime(data_temp['MESS_DATUM'], format='%Y%m%d%H%M')
    data_temp['TT_10'].interpolate(inplace=True)

    # Zeitraum-Masken
    startdate = pd.to_datetime(startdate)
    enddate = pd.to_datetime(enddate)
    maske_solar = (data_solar['MESS_DATUM'] >= startdate) & (data_solar['MESS_DATUM'] <= enddate)
    maske_temp = (data_temp['MESS_DATUM'] >= startdate) & (data_temp['MESS_DATUM'] <= enddate)

    # Globalstrahlung
    globalstrahlung = (10000 / 600) * data_solar.loc[maske_solar, 'GS_10']

    # Solarmodul und Solarpark
    class Solarmodul:
        def __init__(self, nennleistung, temperaturkoeff, laenge, breite, hoehe, einheit='mm'):
            faktor = {'mm': 1e-3, 'cm': 1e-2, 'm': 1}[einheit]
            self.nennleistung = nennleistung
            self.temperaturkoeff = temperaturkoeff
            self.laenge = laenge * faktor
            self.breite = breite * faktor
            self.flaeche = self.laenge * self.breite

    class Solarpark:
        def __init__(self, n_module, azimuth, modul, neigungswinkel, strahlungsfaktor, einheit='deg'):
            self.nennleistung = n_module * modul.nennleistung
            self.modul = modul
            self.strahlungsfaktor = strahlungsfaktor

        def leistung(self, G, T, einheit='kW'):
            G_eff = G * self.strahlungsfaktor
            P = (G_eff / 1000) * self.nennleistung * (1 + self.modul.temperaturkoeff * (T - 25))
            einheiten = {'W': 1, 'kW': 1e3, 'MW': 1e6}
            return P / einheiten[einheit]

    modul = Solarmodul(550, -0.0035, 2278, 1133, 30)
    winkel = 30
    sonnenwinkel = 0
    n = 1000
    df_faktor = pd.read_csv(path_faktor, index_col=0)
    wichtungsfaktor = df_faktor.loc[sonnenwinkel, str(winkel)] / 100
    park = Solarpark(n, 0, modul, winkel, wichtungsfaktor)

    # Leistung berechnen
    temp = data_temp.loc[maske_temp, 'TT_10'].values
    leistung = park.leistung(globalstrahlung.values, temp)

    # Tagesertrag berechnen
    df_leistung = pd.DataFrame({
        'Zeit': data_solar.loc[maske_solar, 'MESS_DATUM'],
        'Leistung': leistung
    })
    df_leistung['Datum'] = df_leistung['Zeit'].dt.date
    tagesertrag_all = df_leistung.groupby('Datum')['Leistung'].sum() * 600 / 3600  # in kWh

    # Tagesmitteltemperatur & Wasserverbrauch
    tagesmittel_temp_all = data_temp.groupby(data_temp['MESS_DATUM'].dt.date)['TT_10'].mean()
    tagesmittel_temp_all = tagesmittel_temp_all.reindex(tagesertrag_all.index)
    wasserbedarf_liter_all = tagesmittel_temp_all.apply(lambda t: wasserverbrauch(t, pflanzen=pflanzen))

    # Pumpenverbrauch pro Zeitschritt (wie viele Zeitschritte pro Tag?)
    zeitschritt_min = (data_solar['MESS_DATUM'].iloc[1] - data_solar['MESS_DATUM'].iloc[0]).seconds // 60
    zeitschritt_stunden = zeitschritt_min / 60

    # Grundverbrauch pro Zeitschritt
    grundverbrauch_kwh_zeitschritt = grundverbrauch_watt / 1000 * zeitschritt_stunden

    # DataFrame für alle Zeitschritte im betrachteten Zeitraum
    zeiten = data_solar.loc[maske_solar, 'MESS_DATUM']
    df_verbrauch = pd.DataFrame({
        'Datum': zeiten.dt.date,
        'Grundverbrauch': grundverbrauch_kwh_zeitschritt,
    })

    # Pumpenverbrauch auf Zeitschritte verteilen (pro Tag auf Zeitschritte gleichmäßig)
    pumpenverbrauch_kwh_all = wasserbedarf_liter_all * 0.0006  # Tageswert
    pumpenverbrauch_zeitschritt = pumpenverbrauch_kwh_all / zeiten.groupby(zeiten.dt.date).size()
    df_verbrauch['Pumpenverbrauch'] = df_verbrauch['Datum'].map(pumpenverbrauch_zeitschritt)

    # Gesamtverbrauch pro Zeitschritt
    df_verbrauch['Gesamt'] = df_verbrauch['Grundverbrauch'] + df_verbrauch['Pumpenverbrauch']

    # Tagesverbrauch aufsummieren
    verbrauch_all = df_verbrauch.groupby('Datum')['Gesamt'].sum()

    # Plot im Wasserplot-Stil mit zwei y-Achsen
    fig = Figure(figsize=(6, 2.1), dpi=100, constrained_layout=True, facecolor="#11393D")
    ax1 = fig.add_subplot(111)
    ax1.set_facecolor("#11393D")

# Linke y-Achse: PV-Ertrag
    ax1.plot(tagesertrag_all.index, tagesertrag_all, marker="o", markersize=3, color='lightcyan', linewidth=0.8, label='PV-Ertrag (kWh)')
    ax1.set_ylabel("PV-Ertrag (kWh)", fontsize=8, color='lightcyan')
    ax1.tick_params(axis='y', labelsize=6, colors="lightcyan")
    ax1.tick_params(axis='x', labelsize=6, rotation=45, colors="white")
    ax1.set_xlabel("Datum", fontsize=8, labelpad=2, color="white")
    ax1.xaxis.set_major_locator(MaxNLocator(nbins=8, integer=True))
    ax1.grid(True, linestyle="--", color="gray", alpha=0.3)

    # Rechte y-Achse: Verbrauch
    ax2 = ax1.twinx()
    ax2.plot(verbrauch_all.index, verbrauch_all, marker="x", markersize=3, color='gold', linewidth=0.8, linestyle='--', label='Verbrauch (kWh)')
    ax2.set_ylabel("Verbrauch (kWh)", fontsize=8, color='gold')
    ax2.tick_params(axis='y', labelsize=6, colors="gold")

    # Legenden zusammenführen
    lines1, labels1 = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(lines1 + lines2, labels1 + labels2, fontsize=6, facecolor="#11393D", edgecolor="none")

    # Overlay mit Gesamt-Stats
    fig.text(
        0.95, 0.02,
        f"Summe PV: {tagesertrag_all.sum():.1f} kWh\n"
        f"Summe Verbrauch: {verbrauch_all.sum():.1f} kWh",
        ha="right",
        va="bottom",
        fontsize=6,
        color="white",
        bbox=dict(facecolor="#11393D", pad=2, edgecolor="none", alpha=0.7))

    return fig, tagesertrag_all, verbrauch_all

    # Plot im Wasserplot-Stil
    fig = Figure(figsize=(6, 2.1), dpi=100, constrained_layout=True, facecolor="#11393D")
    ax = fig.add_subplot(111)
    ax.set_facecolor("#11393D")
    ax.plot(tagesertrag_all.index, tagesertrag_all, marker="o", markersize=3, color='lightcyan', linewidth=0.8, label='PV-Ertrag (kWh)')
    ax.plot(verbrauch_all.index, verbrauch_all, marker="x", markersize=3, color='gold', linewidth=0.8, linestyle='--', label='Verbrauch (kWh)')
    ax.grid(True, linestyle="--", color="gray", alpha=0.3)
    ax.tick_params(axis='x', labelsize=6, rotation=45, colors="white")
    ax.tick_params(axis='y', labelsize=6, colors="white")
    ax.set_xlabel("Datum", fontsize=8, labelpad=2, color="white")
    ax.set_ylabel("kWh", fontsize=8, labelpad=2, color="white")
    ax.xaxis.set_major_locator(MaxNLocator(nbins=8, integer=True))

    legend = ax.legend(fontsize=6, facecolor="#11393D", edgecolor="none")
    for text in legend.get_texts():
        text.set_color("white")

    fig.text(
        0.95, 0.02,
        f"Summe PV: {tagesertrag_all.sum():.1f} kWh\n"
        f"Summe Verbrauch: {verbrauch_all.sum():.1f} kWh",
        ha="right",
        va="bottom",
        fontsize=6,
        color="white",
        bbox=dict(facecolor="#11393D", pad=2, edgecolor="none", alpha=0.7)
    )

    return fig, tagesertrag_all, verbrauch_all