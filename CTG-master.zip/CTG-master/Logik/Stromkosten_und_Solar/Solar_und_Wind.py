import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')))
import pandas as pd
from matplotlib.figure import Figure
import matplotlib.dates as mdates
from Logik.Windstrom.Windstrom import wind_flow
from Logik.Stromkosten_und_Solar.Solarstrom_und_Verbrauch import pv_flow

def solar_wind_figure():
    _, pv_series, consumption_series = pv_flow()
    _, wind_series, _ = wind_flow()

    df = pd.DataFrame({
        'PV': pv_series,
        'Wind': wind_series,
        'Verbrauch': consumption_series
    }).fillna(0)

    df['Erzeugung'] = df['PV'] + df['Wind']

    fig = Figure(figsize=(6, 2.1), dpi=100, constrained_layout=True, facecolor="#11393D")
    ax1 = fig.add_subplot(111)
    ax1.set_facecolor("#11393D")

    # PV & Wind als Stackplot auf linker Achse
    ax1.stackplot(
        df.index,
        df['PV'],
        df['Wind'],
        labels=['PV-Erzeugung', 'Wind-Erzeugung'],
        colors=['gold', 'skyblue'],
        alpha=0.5
    )
    ax1.plot(df.index, df['PV'], color='orange', linewidth=1.5, label='PV(Linie)')
    ax1.set_ylabel('Erzeugung [kWh]', fontsize=8, color='white')
    ax1.tick_params(axis='y', labelsize=6, colors="white")
    ax1.tick_params(axis='x', labelsize=6, rotation=45, colors="white")
    ax1.set_xlabel("Datum", fontsize=8, labelpad=2, color="white")
    ax1.xaxis.set_major_locator(mdates.MonthLocator())
    ax1.xaxis.set_major_formatter(mdates.DateFormatter('%b'))
    ax1.grid(True, linestyle="--", color="gray", alpha=0.3)

    # Verbrauch als Linie auf rechter Achse
    ax2 = ax1.twinx()
    ax2.plot(
        df.index,
        df['Verbrauch'],
        color='crimson',
        linewidth=2.0,
        linestyle='-',
        label='Verbrauch'
    )
    ax2.set_ylabel('Verbrauch [kWh]', fontsize=8, color='crimson')
    ax2.tick_params(axis='y', labelsize=6, colors="crimson")

    # Legenden zusammenführen
    lines1, labels1 = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    legend = ax1.legend(lines1 + lines2, labels1 + labels2, fontsize=6, facecolor="#11393D", edgecolor="none", loc='upper left')
    for text in legend.get_texts():
        text.set_color("white")

    # Overlay mit Gesamt-Stats
    fig.text(
        0.95, 0.02,
        f"Summe PV: {df['PV'].sum():.1f} kWh\n"
        f"Summe Wind: {df['Wind'].sum():.1f} kWh\n"
        f"Summe Verbrauch: {df['Verbrauch'].sum():.1f} kWh",
        ha="right",
        va="bottom",
        fontsize=6,
        color="white",
        bbox=dict(facecolor="#11393D", pad=2, edgecolor="none", alpha=0.7)
    )

    return fig