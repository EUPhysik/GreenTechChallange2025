import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import customtkinter as ctk
from PIL import Image
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
import os

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
ICON_DIR   = os.path.join(SCRIPT_DIR, "Icons")



# Importe aus der Logik
from Logik.Wasser_und_Temperatur import Wasser_und_Temperatur
from Logik.Wirtschaftlichkeit_Logik.Wirtschaftlichkeit import (
    erhalte_ausgabewerte,
    lade_komponenten,
    lade_verschleissdaten,
    berechne_investitionskosten,
    berechne_verschleisskosten,
    berechne_verkaufsgewinn,
    berechne_rentabilität
)



# Einstellungen
ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("green")


class App(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("Wirtschaftlichkeitsberechnung")
        self.geometry("1280x600")
        self.configure(fg_color="black")

        # Layoutstruktur
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(2, weight=1)

        # Header
        header = ctk.CTkFrame(self, fg_color="black", height=60)
        header.grid(row=0, column=0, columnspan=2, sticky="ew")
        header.grid_columnconfigure(1, weight=1)

        # Pflanze und Titel in einer Linie
        plant_label = ctk.CTkLabel(header, text="🌱", font=("Arial", 68), text_color="#4CAF50")
        plant_label.grid(row=0, column=0, padx=(20, 10), pady=20, sticky="w")

        self.header_label = ctk.CTkLabel(header, text="Wirtschaftlichkeitsberechnung", font=("Arial", 36), text_color="white")
        self.header_label.grid(row=0, column=1, pady=10, sticky="nsew")

        #  Grüner stroke
        line = ctk.CTkFrame(self, height=2, fg_color="green")
        line.grid(row=1, column=0, columnspan=2, sticky="ew")

        # Sidebar
        self.sidebar = ctk.CTkFrame(self, width=130, fg_color="#0B3A3E", corner_radius=0)
        self.sidebar.grid(row=2, column=0, sticky="ns")
        self.sidebar.grid_propagate(False)

        # Icons und Buttons
        self.nav_buttons = {}
        self.icons_normal = {
    "Home": ctk.CTkImage(
        Image.open(os.path.join(ICON_DIR, "Home_weiß.png")), size=(40,40)
    ),
    "Solar": ctk.CTkImage(
        Image.open(os.path.join(ICON_DIR, "sonne_weiß.png")), size=(40,40)
    ),
    "Wind": ctk.CTkImage(
        Image.open(os.path.join(ICON_DIR, "Wind_weiß.png")), size=(40,40)
    ),
    "Invest": ctk.CTkImage(
        Image.open(os.path.join(ICON_DIR, "Invest_weiß.png")), size=(40,40)
    ),
}

       # self.icons_normal = {
            #"Home": ctk.CTkImage(Image.open("Icons/Home_weiß.png"), size=(40, 40)),
            #"Solar": ctk.CTkImage(Image.open("Icons/sonne_weiß.png"), size=(40, 40)),
            #"Wind": ctk.CTkImage(Image.open("Icons/Wind_weiß.png"), size=(40, 40)),
            #"Invest": ctk.CTkImage(Image.open("Icons/Invest_weiß.png"), size=(40, 40)),
        #}
        self.icons_active = {
            "Home": ctk.CTkImage(
                Image.open(os.path.join(ICON_DIR, "Home_grün_t.png")), size=(40, 40)
            ),
            "Solar": ctk.CTkImage(
                Image.open(os.path.join(ICON_DIR, "sonne_grün_t.png")), size=(40, 40)
            ),
            "Wind": ctk.CTkImage(
                Image.open(os.path.join(ICON_DIR, "Wind_grün_t.png")), size=(40, 40)
            ),
            "Invest": ctk.CTkImage(
                Image.open(os.path.join(ICON_DIR, "Invest_grün_t.png")), size=(40, 40)
            ),
        }
        #self.icons_active = {
            #"Home": ctk.CTkImage(Image.open("Icons/Home_grün_t.png"), size=(40, 40)),
            #"Solar": ctk.CTkImage(Image.open("Icons/sonne_grün_t.png"), size=(40, 40)),
            #"Wind": ctk.CTkImage(Image.open("Icons/Wind_grün_t.png"), size=(40, 40)),
            #"Invest": ctk.CTkImage(Image.open("Icons/Invest_grün_t.png"), size=(40, 40)),
        #}

        nav = [("Home", "Home"), ("Solar", "Solar"), ("Wind", "Wind"), ("Invest", "Invest")]
        for page_key, label in nav:
            btn = ctk.CTkButton(
                self.sidebar,
                text=label,
                image=self.icons_normal[page_key],
                compound="top",
                corner_radius=15,
                fg_color="transparent",
                hover_color=None,
                text_color="white",
                font=("Arial", 14),
                command=lambda p=page_key: self.activate_button(p),
            )
            btn.pack(pady=30, padx=20, fill="x")
            self.nav_buttons[page_key] = btn

        # main_area
        self.main_area = ctk.CTkFrame(self, fg_color="black")
        self.main_area.grid(row=2, column=1, sticky="nsew")

        # Seiten
        self.pages = {
            "Home": HomePage(self.main_area),
            "Solar": SolarPage(self.main_area),
            "Wind": WindPage(self.main_area),
            "Invest": InvestPage(self.main_area),
        }

        self.show_page("Home")


    def activate_button(self, name):
        for key, btn in self.nav_buttons.items():
            btn.configure(image=self.icons_normal[key])
        self.nav_buttons[name].configure(image=self.icons_active[name])
        self.show_page(name)

    def show_page(self, name):
        for page in self.pages.values():
            page.grid_forget()
        if name in self.pages:
            self.pages[name].grid(row=0, column=0, sticky="nsew")

            titles={
                "Home": "Wirtschaftlichkeitsberechnung",
                "Solar": "Solarstrom und Kosten",
                "Wind": "Windstrom und Kosten", 
                "Invest": "Investitionsübersicht"
            }

            self.set_title(titles.get(name,""))

    def set_title(self, neuer_titel):
        self.header_label.configure(text=neuer_titel)


# Home-Seite

class HomePage(ctk.CTkFrame):
    def __init__(self, parent):
        super().__init__(parent, fg_color="black")
        self.grid_columnconfigure((0, 1), weight=1)

        green_line = ctk.CTkFrame(self, height=1, fg_color="green")
        green_line.grid(row=1, column=0, columnspan=20, sticky="ew", padx=10, pady=(0, 20))

        green_box = ctk.CTkFrame(self, width=300, height=350, border_color="green", border_width=2, fg_color="black")
        green_box.grid(row=2, column=0, rowspan=3, padx=40, pady=20)

        info_data = [("Investition", 2), ("Betriebskosten", 3), ("Rentabilität", 4)]
        investition, verschleiss, rentabilität = erhalte_ausgabewerte()
        werte = [f"{investition:.2f} €", f"{verschleiss:.2f} €", f"{rentabilität:.2f} €"]

        for index, (text, row) in enumerate(info_data):
            ctk.CTkLabel(self, text=text, font=("Arial", 20)).grid(row=row, column=1, sticky="n", pady=(5, 0))
            box = ctk.CTkFrame(self, width=400, height=110, fg_color="#11393D", corner_radius=10)
            box.grid(row=row, column=1, pady=(30, 60), padx=(80), sticky="nsew")
            ctk.CTkLabel(
                box,
                text=werte[index],
                font=("Arial", 30, "bold"),
                text_color="white"
            ).pack(pady=20)

#class HomePage(ctk.CTkFrame):
    #def __init__(self, parent):
        #super().__init__(parent, fg_color="black")
        #self.grid_columnconfigure((0, 1), weight=1)


        #green_line = ctk.CTkFrame(self, height=1, fg_color="green")
        #green_line.grid(row=1, column=0, columnspan=20, sticky="ew", padx=10, pady=(0, 20))

        #green_box = ctk.CTkFrame(self, width=300, height=350, border_color="green", border_width=2, fg_color="black")
        #green_box.grid(row=2, column=0, rowspan=3, padx=40, pady=20)

        #info_data = [("Rentabilität", 2), ("Betriebskosten", 3), ("Gesamtausgaben", 4)]

        #for text, row in info_data:
            #ctk.CTkLabel(self, text=text, font=("Arial", 20)).grid(row=row, column=1, sticky="n", pady=(5, 0))
            #box = ctk.CTkFrame(self, width=400, height=110, fg_color="#11393D", corner_radius=10)
            #box.grid(row=row, column=1, pady=(30, 60))


# Solar-Seite
class SolarPage(ctk.CTkFrame):
    def __init__(self, parent):
        super().__init__(parent, fg_color="black")
        self.grid_columnconfigure(0, weight=1)
       

       

        info = [("Solaranlage", 1), ("Kostendeckung", 2)]

        for label, row in info:
            ctk.CTkLabel(self, text=label, font=("Arial", 20)).grid(row=row * 2 - 1, column=0, pady=(10, 0), padx=(100, 0), sticky="w")
            box = ctk.CTkFrame(self, width=600, height=210, fg_color="#11393D", corner_radius=10)
            box.grid(row=row * 2, column=0, pady=(20, 20), padx=(100, 0), sticky="w")


# Wind-Seite

from Logik.Wasser_und_Temperatur.Wasser_und_Temperatur import auswertung
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

class WindPage(ctk.CTkFrame):
    def __init__(self, parent):
        super().__init__(parent, fg_color="black")
        self.grid_columnconfigure(0, weight=1)


        info = [("Windstrom", 1), ("Wasserkosten und Verbrauch", 2)]

        for label, row in info:
            ctk.CTkLabel(self, text=label, font=("Arial", 20)).grid(row=row * 2 - 1, column=0, pady=(10, 0), padx=(100, 0), sticky="w" )
            box = ctk.CTkFrame(self, width=600, height=210, fg_color="#11393D", corner_radius=10)
            box.grid(row=row * 2, column=0, pady=(20, 20), padx=(100, 0), sticky="w")

        # Figur für Wasserverbrauch

        #if label== "Wasserkosten und Verbrauch":
            #fig = Wasser_und_Temperatur.auswertung()
            #fig= Figure(figsize=(6, 2.1), dpi=100)
            #ax = fig.add_subplot(111)
            #fig.tight_layout(pad=0.3)
            ##fig = Wasser_und_Temperatur.auswertung("Logik/Wasser_und_Temperatur/Temperaturdaten.csv")
            #canvas = FigureCanvasTkAgg(fig, master=box)
            #widget = canvas.get_tk_widget()
            #widget.pack(fill="both", expand=True)

            #canvas.get_tk_widget().grid(row=3, column=0, pady=(20, 20), padx=(100, 0), sticky="w")
            #canvas.draw()
            fig = auswertung()

        # 1:1 in die CTk-Canvas ein
        canvas = FigureCanvasTkAgg(fig, master=box)
        widget = canvas.get_tk_widget()
        widget.pack(fill="both", expand=True)
        canvas.draw()

# Invest-Seite
class InvestPage(ctk.CTkFrame):
    def __init__(self, parent):
        super().__init__(parent, fg_color="black")
        self.grid_rowconfigure((1, 2), weight=1)
        
        info = [("nochkeinplan",1), ("Total",2)]

        ctk.CTkLabel(self, text="Komponenten", font=("Arial", 20)).grid(
        row=0, column=0, padx=40, pady=(20, 0), sticky="w"
)
        Komponenten_box= ctk.CTkFrame(self, width= 300, height=400, fg_color="#11393D")
        Komponenten_box.grid(row=1, column=0, rowspan=3, padx=40, pady=20)


        for text, row in info:
            ctk.CTkLabel(self, text=text, font=("Arial", 20)).grid(row=row, column=1, sticky="n", pady=(5, 0))
            box = ctk.CTkFrame(self, width=400, height=110, fg_color="#11393D", corner_radius=10)
            box.grid(row=row, column=1, pady=(30, 60))

        

if __name__ == "__main__":
    app = App()
    app.mainloop()

   