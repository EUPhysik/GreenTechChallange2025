import matplotlib.pyplot as plt
from collections import defaultdict
from datetime import datetime
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
from collections import defaultdict
from datetime import datetime
import os
import matplotlib.dates as mdates
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATEN_PFAD = os.path.join(SCRIPT_DIR, "Wetter_Daten_Dortmund.txt")

def wasserverbrauch(temp, pflanzen=10):
    """Berechnet Literverbrauch pro Tag für gegebene Temperatur."""
    if temp < 5:
        basis = 0.05
    elif temp > 35:
        basis = 0.7
    else:
        basis = 0.05 + (temp - 5) * (0.65 / 30)
    return basis * pflanzen
def wasserverbrauch(temp, pflanzen=10):
    if temp < 5:
        basis = 0.05
    elif temp > 35:
        basis = 0.7
    else:
        basis = 0.05 + (temp - 5) * (0.65 / 30)
    return basis * pflanzen

def auswertung(pflanzen=10, wasserpreis=0.001263):
    # — Daten einlesen und Mitteltemperaturen berechnen —
    tageweise_temp = defaultdict(list)
    with open(DATEN_PFAD, 'r', encoding='utf-8') as f:
        next(f)
        for zeile in f:
            teile = zeile.strip().split(";")
            if len(teile) < 32 or teile[31] in ("", "-999"):
                continue
            try:
                datum = datetime.strptime(teile[2], "%Y-%m-%d").date()
                temp  = float(teile[31].replace(",", "."))
                tageweise_temp[datum].append(temp)
            except:
                continue

    tage      = sorted(tageweise_temp)
    verbrauch = [ wasserverbrauch(sum(temps)/len(temps), pflanzen)
                  for temps in (tageweise_temp[d] for d in tage) ]
    kosten    = [ v * wasserpreis for v in verbrauch ]

    gesamtverbrauch = sum(verbrauch)
    gesamtkosten    = sum(kosten)

    # — Figure anlegen mit grünem Hintergrund —
    fig = Figure(
        figsize=(10, 3.1),
        dpi=100,
        constrained_layout=True,
        facecolor="#11393D"
    )
    ax = fig.add_subplot(111)
    ax.set_facecolor("#11393D")

    # — Verbrauch und Kosten plotten —
    ax.plot(tage, verbrauch, marker='o', markersize=3,
            linewidth=0.8, color='lightcyan', label="Verbrauch (L)")
    ax.plot(tage, kosten,    marker='x', markersize=3,
            linewidth=0.8, color='gold',     label="Kosten (€)")

    # — Achsen, Gitter und Ticks in Weiß —
    ax.grid(True, linestyle="--", color="gray", alpha=0.3)
    ax.tick_params(axis='x', labelsize=6, rotation=45, colors="white")
    ax.tick_params(axis='y', labelsize=6, colors="white")
    ax.set_xlabel("Datum",             fontsize=8, labelpad=2, color="white")
    ax.set_ylabel("Liter / €",         fontsize=8, labelpad=2, color="white")
    ax.set_title("Wasserverbrauch & Kosten", fontsize=10, pad=4, color="white")

    # — Legende in Weiß auf grün —
    legend = ax.legend(fontsize=6, facecolor="#11393D", edgecolor="none")
    for text in legend.get_texts():
        text.set_color("white")

    # — Overlay mit Gesamt-Stats UND Wasserpreis —
    fig.text(
        0.95, 0.02,
        f"Pflanzen: {pflanzen}\n"
        f"Preis: {wasserpreis:.2f} €/L\n"
        f"Summe: {gesamtverbrauch:.1f} L\n"
        f"Kosten: {gesamtkosten:.2f} €",
        ha="right",
        va="bottom",
        fontsize=6,
        color="white",
        bbox=dict(facecolor="#11393D", pad=2, edgecolor="none", alpha=0.7)
    )

    return fig
#def auswertung(pflanzen=10, wasserpreis=0.001263):
 
    tageweise_temp = defaultdict(list)
    with open(DATEN_PFAD, 'r', encoding='utf-8') as f:
        next(f)  
        for zeile in f:
            teile = zeile.strip().split(";")
            if len(teile) < 32 or teile[31] in ("", "-999"):
                continue
            try:
                datum = datetime.strptime(teile[2], "%Y-%m-%d").date()
                temp = float(teile[31].replace(",", "."))
                tageweise_temp[datum].append(temp)
            except:
                continue

    
    tage = sorted(tageweise_temp)
    verbrauch = [
        wasserverbrauch(sum(temps) / len(temps), pflanzen)
        for temps in (tageweise_temp[d] for d in tage)]

    kosten = [v * wasserpreis for v in verbrauch]
    gesamtverbrauch = sum(verbrauch)
    gesamtkosten = sum(kosten)

    
    fig = Figure(figsize=(6, 2.1), dpi=100, constrained_layout=True, facecolor="#11393D", edgecolor="#11393D")
    ax1 = fig.add_subplot(111)
    ax1.set_facecolor("#11393D")
    ax2 = ax1.twinx()
    ax1.plot(tage, verbrauch, marker='o', markersize=3,
             linewidth=0.8, color='lightcyan', label="Verbrauch (L)")
    ax2.plot(tage, kosten,    marker='x', markersize=3,
             linewidth=0.8, color='gold',    label="Kosten (€)")

    ax1.grid(True, linestyle="--", color="gray", alpha=0.3)
    ax1.tick_params(axis='x', labelsize=6, rotation=45, colors="white")
    ax1.tick_params(axis='y', labelsize=6, colors="white")

    # 5) Titel und Labels klein + weiß
    ax1.set_title("Wasserverbrauch je Tag",
                  fontsize=10, pad=4, color="white")
    ax1.set_xlabel("Datum", fontsize=8, labelpad=2, color="white")
    ax1.set_ylabel("Liter", fontsize=8, labelpad=2, color="white")

    # 6) ggf. Legende weiß einfärben
    legend = ax1.legend(fontsize=6, facecolor="#11393D", edgecolor="none")
    for text in legend.get_texts():
        text.set_color("white")

    return fig

    ax1.set_ylabel("Wasserverbrauch (L)", fontsize=8, labelpad=2)
    ax2.set_ylabel("Kosten (€)",           fontsize=8, labelpad=2)

    ax1.set_title("Wasserverbrauch & Kosten je Tag", fontsize=10, pad=4)
    ax1.tick_params(axis='x', labelsize=6, rotation=45)
    ax1.tick_params(axis='y', labelsize=6)
    ax2.tick_params(axis='y', labelsize=6)

  
    lines, labels = ax1.get_lines()+ax2.get_lines(), \
                    [l.get_label() for l in ax1.get_lines()+ax2.get_lines()]
    ax1.legend(lines, labels, fontsize=6, loc="upper left")

   
    
    fig.text(0.95, 0.02,
             f"Summe: {gesamtverbrauch:.1f} L\nKosten: {gesamtkosten:.2f} €",
             ha="right", va="bottom", fontsize=6, color="white",
             bbox=dict(facecolor="#11393D", pad=2, edgecolor="none", alpha=0.5))

    return fig